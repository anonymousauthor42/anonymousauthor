---
layout: article
title: Adversarial attacks on probabilistic models
---

## Adversarial attack for classification

The by far most common domain of the "adversarial attack" community is classificationm, especially natural image classification. Thereby $f$ is a classifier which predicts some label $y$ i.e. $f: \mathbb{R}^d \rightarrow \{0, ..., c\}$. We typically distinguish a **targeted** from a **untargeted** attack. In the first case we have a specific target $t \in \{0, ..., c\}$ in mind. An adversarial attack is then typically defined as the following optimization problem

$$ \delta^* = \argmin_\delta || \delta || \text{  s.t.  } f(x+\delta) = t$$

In the second case we typically define it as

$$ \delta^* = \argmin_\delta || \delta || \text{  s.t.  } f(x+\delta) \neq  f(x)$$

i.e. we want a prediction that is different that that of $x$. Note if our classifier is Bayes optimal and be $y$ the closest point to $x$ with $f^*(x) \neq f^*(y)$, then $\delta^* = -x + y$. This can be thought of the **natural adversarial robustness** of the corresponding classification problem. For example, clearly we can easily trasform an 9 into an 8, whereas it is harder to transform a 9 unto a 5.

Computationally  one can further distinguish **white box** and **black box** attacks. In the former we have full access to $f$ and can thus approximatly solve these optimization problems using numerical optimization methods as gradient decent. For the later we only have access to the input and outputs, thus have to solve it by "brute force" or optimization techniques like genetic algorithms or Bayesian optimization.

## Generalized adversarial attacks

We will now generalize the notion of adversarial attacks to any supervised domain. Be $X,Y \sim p^*(x,y) = p^*(y|x)p^*(x)$. In a statistical setting the true generative model $p^*$ is assumed to be unknown and we only be able to observe a limited dataset $D = \{(x_i, y_i)\}_{i=1}^n$. In a Bayesian setting we assume that the true generative model is given by $p_\theta(x,y)$ whereas we typically either have access to the density $p_\theta(x,y)$ (standard Bayesian inference) or atleast can get samples from it (simulation based inference).

Our goal is to find a function $f^*: \mathcal{X} \rightarrow \mathcal{P}(\mathcal{Y}): f^*(x) = p(y|x)$, in a statistical setting this typically is simplified to an point estimate i.e. $f^*: \mathcal{X} \rightarrow \mathcal{Y}: f^*(x) = \mathbb{E}_y[y|x]$. An arbitrary learning algorithm constrained on a parameteric set of function does return an empirical estimate denoted as $f_\phi$.

> **Definition: Adversarial attack**: Given an arbitrary measure of difference $d_Y(\cdot, \cdot)$ on ($\mathcal{P}(\mathcal{Y})$ or $\mathcal{Y}$ depending on the image space of $f$) and $||\cdot||_X$ on $\mathcal{X}$.  We define targeted adversarial attack of strength $\epsilon \in \mathbb{R}$ for target $t$ as
> $$ \delta^* = \argmin_\delta d_Y(f(x+ \delta), t) \text{  s.t.  } || \delta ||_X\leq \epsilon. $$
> For an untargeted attack we equivalently define
> $$ \delta^* = \argmax_\delta d_Y(f(x+ \delta), f(x)) \text{  s.t.  } || \delta ||_X\leq \epsilon $$

This definition includes many domains ranging from classification, regression, conditional density estimation to Bayesian inference. In most application $\mathcal{X} = \mathbb{R}^n$ thus $||\cdot||_X$ is typically choosen to be an euclidean norm. Depending on the image domain of our model $d_Y$ can range form probabilistc divergences, distance of point estimate to euclidean distances.

By this definition we can get a adversarially robust classifier by minimizing the min-max loss
$$ \mathcal{L}_{minmax}(x,y) =  \mathbb{E}_{p^*(x)} \left[ \max_\delta \mathcal{L}(x +  \delta, y) \right] \text{ s.t.} ||\delta||_X \leq \epsilon  $$
which can be approximated by adversarial training. Alternative try to instead constrain $\max_\delta \mathcal{L}(x +  \delta, y)$ directly e.g. through Lipschitz constraints. 

While this is the natural extension from definitions originated from the natural image classification community. It has some flaws when adapted to other domains, as we will see. From now on we will focus on untargeted attacks.

## A flaw within this definition

For images it is kind clear that small pertubation or even minor rotations or displacements should not change the predicted label. It follows directly that

$$ \argmax_y p^*(y|x) =  \argmax_y p^*(y|x + \delta)$$

for all such pertubations $\delta$. Yet in a general setting clearly

$$ p^*(y|x) \neq p^*(y| x + \delta) $$

i.e. if we perform regression on a non-constant function $g$ then obviously $g(x) \neq g(x + \delta)$ for all $\delta$. Consequently for the optimal model $f^*$, we have that

$$  d_Y(f^*(x+ \delta), f^*(x)) = d_Y(p^*(y|x)|| p^*(y|x+\delta)) \geq 0 $$

A common defense strategy is to make the function **locally robust** i.e. by making $f$ more "smooth" through randomized smoothing, Lipschitz constraints or Jacobian regularization. This indeed by definition tries to minimize $d_Y(f^*(x+ \delta), f^*(x)) = d_Y(p^*(y|x)|| p^*(y|x+\delta))$ and thus is "optimal" only for the constant function. Thus if we enforce $d_Y(p^*(y|x)|| p^*(y|x+\delta)) \leq L||\delta||$ for all x and $\delta$ the  generalization error must increase if $d_Y(p^*(y|x)|| p^*(y|x+\delta)) \geq L||\delta||$ for some $x, \delta$.

This is a widely observed phenomena and a controversial topic: *Is there a tradeoff between adversarial robustness and accuracy?* Both empirical and theoretical evidence for this exist. Most techniques that induce adversarial robustness do often lead to reduced test accuracy on clean data. To discuss this topic more deeply, we have to seperate two sets of possible pertubations.

### Reducible adversarial pertubations

This can be thought as the set of pertubations, which always stem form a bug in the model $f$ and do not exploit the **natural adversarial robustness** of the underlying problem. Blind minimization of the adversarial risk of such pertubations, thus **do not lead to a reduction within the generalization error**.

To discuss this we have to introduce the notion of **consistent pertubation** [4].

> **Definition(consistent):** We call a pertubation $\delta$ consistent if and only if
> $$ d_Y(p^*(y|x), p^*(y|x + \delta)) = 0 $$

This encodes the notion of distributional **invariance**. If a problem is invariant to reotations, then also the prediction should be fully be invariant to it. This can be achived by specializing the architecture to be invariant to e.g. roations. The problem is that we typically do not know from such invariance a priori. Let's consider a simple example
$$ p^*(y|x) = \mathcal{N}(y; x, \sigma^2 I) $$
then
$$ d_y(p^*(y|x), p^*(y|x + \delta)) = \frac{1}{2\sigma^2} || \delta||_2^2 + const.$$
Thus the set of consistent pertubations is given by
$$ C(x) = \{0 \}$$
As we can see this definition may be to strict. So let's relax it a bit:

> **Definition($\kappa$-consistent):** We call a pertubation $\delta$ $\kappa$-consistent if and only if
> $$ d_Y(p^*(y|x), p^*(y|x + \delta)) \leq \kappa $$

In the previous Gaussian example we obtain the set of all $\kappa$ consistent pertuabtions as
$$ C_\kappa(x) = \{ \delta \ : \ || \delta||_2^2 \leq 2\sigma^2 \kappa \}$$

With this we are now able to define an **unnatural adversarial example** as 
$$ \delta^* = \argmax_\delta (\kappa - d_Y(f(x+ \delta), f(x))) \text{  with }  \delta \in C_{\kappa}(x) $$

### Irreducible adversarial pertubations

This can be thought as the set of pertubations, which exploit the **natural adversarial robustness** of the underlying problem. Hence we can define an **natural adversarial attack** as

$$ \delta^* = \argmax_\delta d_Y(f(x+ \delta), f(x))  \text{  s.t. }  d_Y(f(x+ \delta), p^*(y|x + \delta)) = 0$$

Note however this no longer matches the definition of "adversarial intent". Afterall if you change the prediction of your classififer by transforming an 9 to an 8, would you consider this an attack on your model?

## True "adversarial" attacks

Based on this analysis we can say that an attack with "adversarial" attack should not exploit the natural adversarial robustness, but should exploit the robustness of our model. Leading to the following definition

$$ \delta^* = \argmax_\delta d_Y(f(x+ \delta), f(x)) - d_Y(p^*(y|x+\delta), f(x+\delta))  \text{  s.t. }  ||\delta||_X \leq \epsilon $$

This tries to maximize the distance between predictions with minimal approximiation error.



## Application to simulation-based conditional density estimaiton

DO THE ABOVE ...








* [1] Adversarial Attacks on Probabilistic Autoregressive Forecasting Models
* [2] Adversarial Robustness of Flow-Based Generative Models
* [3] Adversarial Attacks on Variational Autoencoders
* [4] Understanding and Mitigating the Tradeoff Between Robustness and Accuracy
* [5] Theoretically Principled Trade-off between Robustness and Accuracy