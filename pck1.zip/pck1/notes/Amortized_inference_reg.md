
# Amortized Bayesian inference and regularization

## Introduction

Given a fixed generative model

$$ p(x, \theta) = p(x|\theta)p(\theta)$$

we define an *amortized Bayesian inference* problem variationally as an optimization problem over a class of functions $f \in \mathcal{F}$ with $f: \mathcal{X} \rightarrow \mathcal{Q}$ where $\mathcal{Q} \subset \mathcal{P}(\theta)$ i.e. a function which maps into the space of all probability distributions on $\theta$. Often $\mathcal{Q} = \{ q_\phi | \phi \in \Phi \}$ and $f: \mathcal{X} \rightarrow \Phi$ i.e. we have an underling *parameteric family* and thus can simply learn a function that maps on the parameters. For notational simplicity we will thus denote the image of $f$ by $q_f(\theta| x)$.

The target of the optimization will be the posterior distribution $p(\theta|x)$ as defined by the given generative model.

Mathematically we can hence define the problem generally as

$$ f^* = \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ D(p(\theta|x) || q_f(\theta|x))  \right] $$

where $D$ is an arbitrary divergence which satisfies $D(p||q) > 0$ and $D(p||q) = 0 \iff p=q$. Thus given that $f$ and $\mathcal{Q}$ has infinite capacity it follows that

$$ f^*(x) = p(\theta|x)$$

Usually we don't have access to the marginal $p(x)$ but only have samples $x_1, \dots, x_n \sim p(x)$. We thus obtain an empirical estimate of $f^*$ by instead optimimizing

$$ \hat{f} = \argmin_{f\in\mathcal{F}}\frac{1}{N} \sum_{i=1}^N\left[ D(p(\theta|x_i) || q_f(\theta|x_i))  \right] $$

which however has all the caviates as standard machine learning problems i.e. $\hat{f}(x_i) = p(\theta| x_i)$ but $\hat{f}(x) = ?$... . Further as f

The standard way learn something is to put inductive biases into the learning problem. This can be done by constrainting $\mathcal{F}$. Typically we use some parameteric family $\mathcal{F}_\Psi = \{f_\psi | \psi \in \Psi\}$ i.e. neural networks and thus can instead optimize over it's parameters

$$ \psi^* = \argmin_{\psi \in \Psi}\frac{1}{N} \sum_{i=1}^N\left[ D(p(\theta|x_i) || q_\psi(\theta|x_i))  \right]$$

In practise $\mathcal{F}_\Psi$ is still a very large class, thus we may require more regularization to avoid overfitting.

### Amortized inference with the forward KL divergence

The divergence $D$ for any pair of distributions $p$ and $q$ is usually intractable. Yet for some choices there atleast exist tractable approximaitons. This is the case for we choose 
$$D(p(\theta|x_i) ||q_f(\theta|x)) = D_{KL}(p(\theta|x_i) ||q_f(\theta|x)) = \mathbb{E}_{p(\theta|x)} \left[ \log \frac{p(\theta|x)}{q_f(\theta|x)}\right]$$

We can hence write the loss as following

$$ \begin{align*}f^* &= \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ D_{KL}(p(\theta|x) || q_f(\theta|x))  \right]\\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[  \mathbb{E}_{p(\theta|x)} \left[ \log \frac{p(\theta|x)}{q_f(\theta|x)}\right] \right] \\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x,\theta)} \left[-\log q_f(\theta|x)   \right] \end{align*}$$

We can easily approximate it by using samples $(x_i, \theta_i) \sim p(x,\theta)$ and instead optimizing

$$  \hat{f} = \argmin_{f\in\mathcal{F}}\frac{1}{N} \sum_{i=1}^N - \log q_f(\theta_i|x_i)$$

This is the fundation on which many new simulation-based-inference methods (SBI) are based, especially SNPE. This is mainly because it is "likelihood-free" i.e. it does not require evaluation of the likelihood function but only samples from it! Thus we will call it $\mathcal{L}_{SBI}$.



### Amortized inference with reverse KL divergence

This seems very similar, right? But it actually will end up to do very different things, especially if we start to regularize! The subtle difference is that we instead conisder
$$D(p(\theta|x_i) ||q_f(\theta|x)) = D_{KL}(q_f(\theta|x)||p(\theta|x_i)) = \mathbb{E}_{q_f(\theta|x)} \left[ \log \frac{q_f(\theta|x)}{p(\theta|x)}\right]$$

The optimization problen can thus be written as

$$ \begin{align*}f^* &= \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ D_{KL}(p(\theta|x) || q_f(\theta|x))  \right]\\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[  \mathbb{E}_{q_f(\theta|x)} \left[ -\log \frac{p(\theta,x)}{q_f(\theta|x)}\right] \right] \\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[  -\mathcal{L}_{ELBO} (x,q_f) \right] \end{align*}$$

which only requires to evalute the joint density $p(x, \theta)$ but no samples form it. Notice that it uses the well-known ELBO (Evidence Lower Bound). This is e.g. is used in Variational Autoencoders. We thus call it $\mathcal{L}_{VI}$

## Denoising/Randomized smoothing regularization

A form of regularization can be to inject noise $\delta$ into the inference model, then instead try to learn the posterior distirbution with $q_f(\theta|x + \delta) = p(\theta|x)$ for all $\delta \sim p(\delta)$. As we will see, both $\mathcal{L}_{SBI}$ and $\mathcal{L}_{VI}$ will lead to very different results under the same distribution.

Be $\tilde{x} = x + \delta$, which thus defines a conditional distribution $p(\tilde{x}|x)$. We can extend our generative model to

$$ p(\tilde{x}, x, \theta) = p(\tilde{x}|x)p(x|\theta)p(\theta)$$

### Denoising Amortized inference with the forward KL divergence

We can update our objective by instead considering

$$ f^* = \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ \mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}(p(\theta|x) || q_f(\theta|\tilde{x}))  \right] \right] $$

So far so fine. Let's see what $f^*$ we learn using this modification. We can rewrite the objective as following

$$ \begin{align*} f^* &= \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ \mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}(p(\theta|x) || q_f(\theta|\tilde{x}))  \right] \right] \\ 
&= \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x, \tilde{x})} \left[ \mathbb{E}_{p(\theta|x)} \left[ -\log q_f(\theta|\tilde{x}) \right]  \right]  \\ 
&= \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x, \tilde{x}, \theta)} \left[  -\log q_f(\theta|\tilde{x}) \right]    \\ 
&= \argmin_{f\in\mathcal{F}} \int_\mathcal{X} \int_{\tilde{\mathcal{X}}} \int_\Theta   -\log q_f(\theta|\tilde{x}) p(x,\tilde{x}, \theta)dxd\tilde{x}d\theta   \\ 
&= \argmin_{f\in\mathcal{F}}  \int_{\tilde{\mathcal{X}}} \int_\Theta   -\log q_f(\theta|\tilde{x}) \int_\mathcal{X}p(x,\tilde{x}, \theta)dxd\tilde{x}d\theta   \\
&=  \argmin_{f\in\mathcal{F}}  \int_{\tilde{\mathcal{X}}} \int_\Theta   -\log q_f(\theta|\tilde{x}) p(\tilde{x}, \theta)d\tilde{x}d\theta   \\
&=  \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(\tilde{x}, \theta)} \left[ -\log q_f(\theta|\tilde{x}) \right]   \\
&=  \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(\tilde{x})} \left[D_{KL}(p(\theta|\tilde{x}) || q_f(\theta| \tilde{x})) \right] 
\end{align*}$$

This is interesting as we are no longer learning the true posterior distribution of the original generative model, but instead learn the posterior distribution of a different model, which accounts for the fact that the observations are perturbed through $p(\tilde{x}|x)$...

So our model won't learn at all to **denoise**, but instead will **learn to infer** with noise. Typically this leads to rather *conservative* posteriors i.e. with a lot of variance.

Note that we can do the following

$$ p(\theta|x)  = \int p(\theta|\tilde{x}) p(\tilde{x}| x) d\tilde{x} = \mathbb{E}_{p(\tilde{x}|x)} \left[ p(\theta|\tilde{x}) \right] \approx \mathbb{E}_{p(\tilde{x}|x)} \left[ q_f(\theta|\tilde{x}) \right] $$
to recover the posterior for true data.

### Denoising Amortized inference with the reverse KL divergence

We can agian update our objective by instead considering

$$ f^* = \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ \mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}( q_f(\theta|\tilde{x})||p(\theta|x))  \right] \right] $$

which we can rewrite as following


$$ \begin{align*}f^* &= \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ \mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}( q_f(\theta|\tilde{x})||p(\theta|x))  \right]  \right]\\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[ \mathbb{E}_{p(\tilde{x}|x)} \left[  \mathbb{E}_{q_f(\theta|\tilde{x})} \left[ -\log \frac{p(\theta,x)}{q_f(\theta|\tilde{x})}\right] \right]\right] \\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[  \mathbb{E}_{q_f(\theta,\tilde{x}|x)} \left[ -\log \frac{p(\theta,x)p(\tilde{x}|x)}{q_f(\theta|\tilde{x})p(\tilde{x}|x)}\right]\right] \\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[  \mathbb{E}_{q_f(\theta,\tilde{x}|x)} \left[ -\log \frac{p(\theta,x, \tilde{x})}{q_f(\theta,\tilde{x}|x)}\right]\right] \\ 
&= \argmin_{f\in\mathcal{F}}  \mathbb{E}_{p(x)} \left[ D_{KL}(q_f(\theta, \tilde{x}|x)||p(\theta, \tilde{x}|x)\right] \\ 
 \end{align*}$$

Where we define the variational joint posterior as

$$ q_f(\theta, \tilde{x}|x) = q_f(\theta|\tilde{x}) p(\tilde{x}|x) $$

As the true posterior factorizes as

$$ p(\theta, \tilde{x}| x) = p(\theta|\tilde{x}, x) p(\tilde{x}|x) = p(\theta|x)p(\tilde{x}|x)$$

And thus 

$$q_{f^*}(\theta| \tilde{x}) = p(\theta|x) $$

or in other words the $q_f$ learns to **denoise** perturbed observations from it's noise.

For the special case of $p(\tilde{x}|x) = \mathcal{N}(\tilde{x}; x, \sigma^2 I)$ [2] derived an optimal solution as following. Note that we can rewrite

$$\begin{align*} f^* &= \argmin_{f \in \mathcal{F}} \mathbb{E}_{p(x)} \left[  \mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}(q_f(\theta|\tilde{x}) || p(\theta|x)) \right]  \right]\\
&= \argmin_{f \in \mathcal{F}} \mathbb{E}_{p(x, \tilde{x})} \left[ D_{KL}(q_f(\theta|\tilde{x}) || p(\theta|x)) \right]  \\ 
&= \argmin_{f \in \mathcal{F}} \mathbb{E}_{p(\tilde{x})} \left[ \mathbb{E}_{p(x|\tilde{x})} \left[  D_{KL}(q_f(\theta|\tilde{x}) || p(\theta|x)) \right] \right]  \\
\end{align*} $$

Note that we can rewrite 

$$ \min_{f \in \mathcal{F}}\mathbb{E}_{p(\tilde{x})} \left[ \mathbb{E}_{p(x|\tilde{x})} \left[  D_{KL}(q_f(\theta|\tilde{x}) || p(\theta|x)) \right] \right] \geq  \mathbb{E}_{p(\tilde{x})} \left[  \min_{q \in \mathcal{Q}} \mathbb{E}_{p(x|\tilde{x})} \left[  D_{KL}(q(\theta) || p(\theta|x)) \right] \right]  $$

Assuming our family $\mathcal{F}$ has inifintie capcaity, then we can make this lower bound a equality since we can select an

$$ f^*(\tilde{x}) = \argmin_{q \in \mathcal{Q}}  \mathbb{E}_{p(x|\tilde{x})} \left[  D_{KL}(q(\theta) || p(\theta|x)) \right]$$

i.e. the function performs denoising through $p(x|\tilde{x})$ and then tries to reconstruct the optimal posterior (but is restricted through it's variational family).

Typically we have only an finite amount of data, thus $p(x)$ is an empirical distribution i.e. $\hat{p}(x) = \frac{1}{N} \sum_{i=1}^n \delta_{x_i}(x)$. Under this assumption the explicitly calculate the posterior distribution 

$$ \hat{p}(x|\tilde{x}) = \frac{p(\tilde{x}|x)\hat{p}(x)}{\hat{p}(\tilde{x})} =  \frac{\sum_{i=1}^N\mathcal{N}(\tilde{x}; x, \sigma^2 I) \delta_{x_i}(x)}{\sum_{i=1}^N \mathcal{N}(\tilde{x}; x_i, \sigma^2 I)} = \sum_{i=1}^N\frac{ \exp(-\frac{||\tilde{x} - x||^2}{2\sigma^2})}{\sum_{i=1}^N \exp(-\frac{||\tilde{x} - x||^2}{2\sigma^2})}  \delta_{x_i}(x) = \sum_{i=1}^Nw_\sigma(\tilde{x}, x)  \delta_{x_i}(x)$$

Thus we can reexpress the above optimal function by
$$\mathbb{E}_{p(x|\tilde{x})} \left[  D_{KL}(q(\theta) || p(\theta|x)) \right] = \int  D_{KL}(q(\theta) || p(\theta|x)) \hat{p}(x|\tilde{x}) = \sum_{i=1}^N w_\sigma(\tilde{x}, x_i)  D_{KL}(q(\theta) || p(\theta|x_i)) $$


As a result we obtain

$$ \begin{align*} f^*(\tilde{x}) &= \argmin_{q \in \mathcal{Q}} \sum_{i=1}^N w_\sigma(\tilde{x}, x_i) D_{KL}(q(\theta)||p(\theta|x_i))\\ 
 &= \sum_{i=1}^N w_\sigma(\tilde{x}, x_i) \argmin_{q \in \mathcal{Q}}  D_{KL}(q(\theta)||p(\theta|x_i)) \\
 &= \sum_{i=1}^N w_\sigma(\tilde{x}, x_i) \cdot q^*_{x_i}(\theta) 
 \end{align*} $$

 where we denote $q^*_{x_i}(\theta) = \argmin_{q \in \mathcal{Q}}  D_{KL}(q(\theta)||p(\theta|x_i))$. Given that $\mathcal{Q}$ contains the true posterior, then this simplifies to 

 $$ f^*(\tilde{x}) = \sum_{i=1}^N w_\sigma(\tilde{x}, x_i) \cdot p(\theta|x_i)  $$

 We can now take the limit $N \rightarrow \infty$. We obtain

 $$ \begin{align*} \lim_{N\rightarrow \infty}  \sum_{i=1}^N w_\sigma(\tilde{x}, x_i) \cdot p(\theta|x_i) &= \lim_{N\rightarrow \infty} \frac{\sum_{i=1}^N \exp(-\frac{1}{2\sigma^2} ||\tilde{x} - x_i||^2) p(\theta|x_i)}{\sum_{i=1}^N \exp(-\frac{1}{2\sigma^2} ||\tilde{x} - x_i||^2)}\\ 
 &= \lim_{N\rightarrow \infty} \frac{\frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)p(\theta|x_i)}{\frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)}\\ 
 &=  \frac{ \lim_{N\rightarrow \infty} \frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)p(\theta|x_i)}{\lim_{N\rightarrow \infty}\frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)}\\ 
\end{align*} 
 $$

 So the last step is only valid if the denominator is by no means zero. So let's compute it first!

 $$ \lim_{N\rightarrow \infty}\frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i) = \mathbb{E}_{p(x)} \left[p(\tilde{x}|x) \right] = p(\tilde{x})$$

 We can use the LLN because each $x_i$ is assumed to be iid. sampled from p(x)!
 As a result for any valid input on the support of $p(\tilde{x})$ the denominator is nonzero.

 Let's also consider the nominator

 $$  \lim_{N\rightarrow \infty} \frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)p(\theta|x_i) = \mathbb{E}_{p(x)}\left[ p(\tilde{x}|x)p(\theta|x) \right] = \mathbb{E}_{p(x)}\left[ p(\tilde{x},\theta|x) \right] = p(\tilde{x}, \theta)$$

So after plugin the limits back into it we obtain:

$$ \frac{ \lim_{N\rightarrow \infty} \frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)p(\theta|x_i)}{\lim_{N\rightarrow \infty}\frac{1}{N}\sum_{i=1}^N p(\tilde{x}|x_i)} = \frac{p(\theta, \tilde{x})}{p(\tilde{x})} = p(\theta|\tilde{x}) $$


WTF ................ (so one of both results is wrong XD)




## All right let's try to resolve that fuck

We can rewrite the loss as following

$$
\begin{align*} f_1^* &= \argmin_{f \in \mathcal{F}} \mathbb{E}_{p(x)} \left[  \mathbb{E}_{p(\tilde{x}|x)} \left[ D(q_f(\theta|\tilde{x}) || p(\theta|x)) \right]  \right]\\

f_2^* &= \argmin_{f \in \mathcal{F}} \mathbb{E}_{p(\tilde{x})} \left[ \mathbb{E}_{p(x|\tilde{x})} \left[  D(q_f(\theta|\tilde{x}) || p(\theta|x)) \right] \right]  \\
\end{align*} 
$$

We can see that 

$$ \hat{f}^*_2(\tilde{x}) = \argmin_{q \in \mathcal{Q}}  \mathbb{E}_{p(x|\tilde{x})} \left[  D(q(\theta) || p(\theta|x)) \right]$$

Is clearly an globally optimal solution for the second form. But it also have to be for the first! Note that an obvious 

NOTE: [1] is wrong..., also disproofen by [2] (but not only first lemma is wrong, but also the rest...)

<!-- Note that we can obtain a new variational approximation for clean data $x$, by integrating out the perturbed data i.e.

$$ \tilde{q}_f(\theta | x) = \mathbb{E}_{p(\tilde{x}|x )} \left[ q_f(\theta|\tilde{x})\right] = \int q_f(\theta|x) p(\tilde{x}|x) d\tilde{x}$$

Notice that by the law of iterated expectations we can write any expectation (THIS IS WRONG...)

$$ \mathbb{E}_{p(\tilde{x}|x)} \left[ \mathbb{E}_{q_f(\theta|\tilde{x})} \left[ f(\theta) \right] \right] = \mathbb{E}_{\tilde{q}_f(\theta|x)} \left[ f(\theta) \right] $$

$$\begin{align*}
\mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}(q_f(z|\tilde{x}) || p(\theta | x))  \right] &= \mathbb{E}_{p(\tilde{x}|x)} \left[ \mathbb{E}_{q_f (\theta|\tilde{x})} \log \frac{q_f(\theta|\tilde{x})}{p(\theta| x)}  \right] \\ 

\end{align*}$$ -->

## Adversarial robustness regularization

We can itnerpret them as a special case. This includes
* Adversarial training
* Trades
* Randomized smoothing
* Data augmentation techniques ...
* ...

We donote an adversarial attack 

$$ \tilde{x}^*(x) =  \argmax_{||\tilde{x} - x||  \leq \epsilon }  D(q_f(\theta|x)|| q_f(\theta| \tilde{x})) $$

Then to recover **adversarial training** we have to choose

$$ p(\tilde{x}|x) = \delta( \tilde{x}^*(x) - \tilde{x})$$

As then we recover

$$ f^* = \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ \mathbb{E}_{p(\tilde{x}|x)} \left[ D_{KL}(p(\theta|x) || q_f(\theta|\tilde{x}))  \right] \right] =  \argmin_{f\in\mathcal{F}} \mathbb{E}_{p(x)} \left[ D_{KL}(p(\theta|x) || q_f(\theta|\tilde{x}^*(x)))  \right]   $$

which is equivalent to adversarial training.

Equivalently we can obtain TRADES like algorithms by considering a mixture density

$$ p(\tilde{x}|x) = \lambda \delta(\tilde{x} - x) + (1-\lambda) \delta(\tilde{x}^*(x) - x)$$

So that's nice but let's also look at an alternative divergence.


<!-- ## Analytical example: Generalized linear regression

Let's assume that the inference network is gaussian and linear i.e. we have that $q_f(\theta|y) = \mathcal{N}(\mu(y), \Sigma(y))$$ where $\mu(y) = Cy + b$ and $\Sigma(x) = D$.



We consider a simple gererative model

$$ p(w, y) = \mathcal{N}(y ; w^t x + b, \sigma^2)\mathcal{N}(w;0, I) $$
Clearly the posterior is also Gaussian and standard AMI should converge to the true posterior...

Note that also

$$ p(\tilde{x}, \theta) = \int \mathcal{N}(\tilde{x}; x, \epsilon^2 I) \mathcal{N}(x; L) -->


## References
* [1] https://arxiv.org/abs/1511.06406
* [2] https://arxiv.org/pdf/1805.08913.pdf
