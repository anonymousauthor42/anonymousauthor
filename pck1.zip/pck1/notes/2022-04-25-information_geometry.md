---
layout: article
title: Information geometry and it's application in Machine Learning
---

Information geometry can be thought as part of the *Information sciences* which study the "communication" between data and families of models. In short, they seek to distill information from data to models. These include information theory but also the fields of probability theory, statistics, machine learning and more. 


## A notion of distance 

A main concern of theory of inference is the problem of updating probabilities when new information arises. Typically we pick the "best fitting" model out of a family of distributions and this arises many questions:
* What if we had picked a neighboring distributions?
* How can we distinguish one distribution from another?
* Can we wauntify the difference?

This are inherently **geometic** questions and thus fall into the domain of **information geometry**. More specifiall we will discuss here the notion of "distance" between probability distributions as well as induced statistical manifolds.


## A parametric statistical model as Manifold

A parameteric family of probability distributions is a set of distributions $\mathcal{F}= \{ p_\theta (x) | \theta \in \Theta \}$ labeld by the parameters $\theta$. Typically $\theta \in \mathbb{R}^n$ (or at least we can typically reparamterize them accordingly) and thus each family $\mathcal{F}$ forms a *statistical manifold* in $\mathbb{R}^n$, namely a space in which each point,labeld by coordinates $\theta$, represents a probability distribution $p_\theta (x)$. By interpreting $\mathcal{F}$ as manifold $\mathcal{M}$ one hopes to get some insights into the structure of such a family. For example, one might hope to discover a reasonable measure of "distance" of two distributions within the family.


# References

