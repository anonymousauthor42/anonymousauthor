from rbibm.tasks.gaussian_linear import GaussianLinearTask, HardGaussianLinearTask
from rbibm.tasks.lv_task import LotkaVolterraTask
from rbibm.tasks.hh_task import HHTask
from rbibm.tasks.spatial_sir import SpatialSIRTask
from rbibm.tasks.vae_task import VAETask
from rbibm.tasks.rps_task import RPSTask
from rbibm.tasks.square_task import SquareTask
from rbibm.tasks.sir_task import SIRTask
from rbibm.tasks.glr_tasks import RBFRegressionTask