
TODOs

* Fig0: No defense: Cols: All tasks, Rows: Attack(s)/Different metrics
* Fig1: Cols: Metrics, Rows: Defenses
* Fig2: Cols: Tasks, Rows: Defenses